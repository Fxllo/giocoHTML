var title = document.getElementById("title");
var all = document.getElementById("all");
var score = document.getElementById("score");
var cont = 0;

//music lobby
// var lobby = document.getElementById("lobby");
// document.addEventListener("mouseenter", function () {
//     lobby.play();
// });

var win = document.getElementById("win");
var timer = document.getElementById("timer");

const retryWin = document.getElementById("retryWin");
const retryLose = document.getElementById("retryLose");

title.onclick = game;


function game () {
    title.remove(); //delete start button
    all.remove(); //delete menu on start game

    const allGame = setTimeout(gameEnd, seconds*1000); //game time from user (default: 60s)
    score.innerHTML = "Score: 0/" + sizeObb; //create score
    timer.innerHTML = "00:0";

    //create the target
    var img = document.createElement("img");
    img.src = selectImg;
    document.body.appendChild(img);
    img.setAttribute ("id", "img"); //put id "img" a img
    img.setAttribute("width", size);
    img.setAttribute("height", size);
    img.style.position = "absolute";
    img.style.left = Math.random() * (window.innerWidth - img.offsetWidth) + "px";
    img.style.top = Math.random() * (window.innerHeight - img.offsetHeight) + "px";

    //cronometro inizio game
    let start = new Date();
    setInterval(function(){
        let current = new Date();
        let diff = new Date(current - start);
        let minutes = diff.getUTCMinutes();
        let secondsCrono = diff.getUTCSeconds();
        timer.innerHTML = "0" + minutes + ":" + secondsCrono;
    }, 1000);

    //check click and other features
    var checkImg = document.getElementById("img");
    checkImg.addEventListener("mouseover", function () { //spwan random image
        img.style.left = Math.random() * (window.innerWidth - img.offsetWidth) + "px";
        img.style.top = Math.random() * (window.innerHeight - img.offsetHeight) + "px";
        cont++;
        score.innerHTML = "Score: " + cont + "/" + sizeObb;

        if (cont === sizeObb) { //runs only if u win
            img.remove();
            win.style.display =  "flex";
            win.style.flexDirection = "column";
            win.style.alignItems = "center";
            retryWin.addEventListener("click", function() {
                location.reload();
            });
        }
    });
}


//runs only if u lose
var lose = document.getElementById("lose");

function gameEnd () {
    img.remove();
    lose.style.display =  "flex";
    lose.style.flexDirection = "column";
    lose.style.alignItems = "center";

    retryLose.addEventListener("click", function() {
        location.reload();
    });
}


//difficulty part
var size = "150px";

var easy = document.getElementById("easy");
var normal = document.getElementById("normal");
var hard = document.getElementById("hard");

easy.onclick = function () { //set difficulty to easy
    easy.style.color = "#D94F04";
    normal.style.color = "white";
    hard.style.color = "white";
    size = "150px";

    document.body.style.background = "linear-gradient(to bottom, skyblue, cornflowerblue)";
}

normal.onclick = function () { //set difficulty to normal
    normal.style.color = "#D94F04";
    easy.style.color = "white";
    hard.style.color = "white";
    size = "100px";

    document.body.style.background = "linear-gradient(to bottom,  #FF8838, #D84924)";
}

hard.onclick = function () { //set difficulty to hard
    hard.style.color = "#D94F04";
    easy.style.color = "white";
    normal.style.color = "white";
    size = "50px";
    
    document.body.style.background = "linear-gradient(to bottom, #0d1a26, #2c3e50, #F51008)";
}

//objective part
//both menu divs
var showObb = document.getElementById("showObb");
var showPhoto = document.getElementById("showPhoto");

//both ranges in the first div
var range = document.getElementById("range");
var rangeSeconds = document.getElementById("rangeSeconds");

//both displays in the first div 
var displayValue = document.getElementById("displayValue");
var displayValueSeconds = document.getElementById("displayValueSeconds");

//var of type of kill
var click = document.getElementById("click");
var hover = document.getElementById("hover");

//button that creates the div
var photo = document.getElementById("photo");
var obb = document.getElementById("obb");

var sizeObb = 60;
var seconds = 60;

range.addEventListener("input", function () { //get values entered from user
    displayValue.textContent = this.value;
    sizeObb = Number(this.value);
});

rangeSeconds.addEventListener("input", function () { //get values entered from user
    displayValueSeconds.textContent = this.value;
    seconds = Number(this.value);
});

obb.onclick = createMenuObb;
photo.onclick = createMenuPhoto;

function createMenuObb () { //show the div on click
    obb.style.color = "#D94F04";
    photo.style.color = "white";
    if (showObb.style.display == "block") {
        showObb.style.display = "none";
        obb.style.color = "white";
    }
        
    else if (showPhoto.style.display == "block") {
        showPhoto.style.display = "none";
        showObb.style.display = "block";
    }
    else 
        showObb.style.display = "block";
}

function createMenuPhoto () { //show the div on click
    photo.style.color = "#D94F04";
    obb.style.color = "white";
    if (showPhoto.style.display == "block") {
        showPhoto.style.display = "none";
        photo.style.color = "white";
    }
    else if (showObb.style.display == "block"){
        showObb.style.display = "none";
        showPhoto.style.display = "block";
    }
    else 
        showPhoto.style.display = "block";
}


//X on the top right corner to close menu
var closeMenuSettings = document.getElementById("closeMenuSettings");
var closeMenuPhoto = document.getElementById("closeMenuPhoto");

closeMenuSettings.addEventListener("click", function () {
    showObb.style.display = "none";
    obb.style.color = "white";
});

closeMenuPhoto.addEventListener("click", function () {
    showPhoto.style.display = "none";
    photo.style.color = "white";
});


//select type
var typeKill = "mouseover";
click.onclick = function () { typeKill = "click"; }
hover.onclick = function () { typeKill = "mouseover"; }


//select photo
var selectImg = "../images/bro.png";

var campa = document.getElementById("campa");
var filippino = document.getElementById("filippino");
var nero = document.getElementById("nero");

campa.onclick = function () { //change border and reset the others
    campa.style.border = "3px solid red";
    filippino.style.border = "none";
    nero.style.border = "none";

    selectImg = "../images/bro.png";
}

filippino.onclick = function () { //change border and reset the others
    filippino.style.border = "3px solid red";
    campa.style.border = "none";
    nero.style.border = "none";

    selectImg = "../images/filippino.png";
}

nero.onclick = function () { //change border and reset the others
    nero.style.border = "3px solid red";
    campa.style.border = "none";
    filippino.style.border = "none";

    selectImg = "../images/marn.jpg";
}