var title = document.getElementById("title");
var all = document.getElementById("all");
var score = document.getElementById("score");
var cont = 1;

//variable menu parts
var easy = document.getElementById("easy");
var normal = document.getElementById("normal");
var hard = document.getElementById("hard");
var photo = document.getElementById("photo");
var obb = document.getElementById("obb");

title.onclick = game;

function game () {
    title.remove(); //delete start button
    all.remove(); //delete menu on start game

    const allGame = setTimeout(gameEnd, seconds*1000); //game time (60s)
    score.innerHTML = "Score: 0"; //create score

    //create the target
    var img = document.createElement("img");
    img.src = "../images/bro.png";
    document.body.appendChild(img);
    img.setAttribute ("id", "img"); //mette id img a img
    img.setAttribute("width", size);
    img.setAttribute("height", size);
    img.style.position = "absolute";
    img.style.left = Math.random() * (window.innerWidth - img.offsetWidth) + "px";
    img.style.top = Math.random() * (window.innerHeight - img.offsetHeight) + "px";

    //check click
    var checkImg = document.getElementById("img");
    checkImg.addEventListener("mouseover", function () {
        img.style.left = Math.random() * (window.innerWidth - img.offsetWidth) + "px";
        img.style.top = Math.random() * (window.innerHeight - img.offsetHeight) + "px";
        score.innerHTML = "Score: " + cont++;

        if (cont == sizeObb+1) {
            img.remove();
            var div = document.createElement("div");
            div.innerHTML = "Sei un demone del SIUMM!!! <br> Hai vinto!!!";
            div.style.textAlign = "center";
            div.style.paddingTop = window.innerHeight / 2;
            div.style.fontSize = "60px";
            div.style.fontWeight = "bold";
            div.style.color = "coral";

            document.body.appendChild(div);
        }
    });
}

function gameEnd () {
    img.remove();
    var div = document.createElement("div");
    div.innerHTML = "Fai schifo!!! <br> Hai perso!!!";
    document.body.appendChild(div);
}


//difficulty part
var size = "100px";
easy.onclick = function () {
    easy.style.color = "coral";
    normal.style.color = "white";
    hard.style.color = "white";
    size = "200px";
}

normal.onclick = function () {
    normal.style.color = "coral";
    easy.style.color = "white";
    hard.style.color = "white";
    size = "100px";
}

hard.onclick = function () {
    hard.style.color = "coral";
    easy.style.color = "white";
    normal.style.color = "white";
    size = "50px";
}


//objective part
var sizeObb = 60;
var seconds = 60;

//both menu divs
var showObb = document.getElementById("showObb");
var showPhoto = document.getElementById("showPhoto");

//both ranges in the first div
var range = document.getElementById("range");
var rangeSeconds = document.getElementById("rangeSeconds");

//both displays in the first div 
var displayValue = document.getElementById("displayValue");
var displayValueSeconds = document.getElementById("displayValueSeconds");

obb.onclick = createMenuObb;
photo.onclick = createMenuPhoto;

range.addEventListener("input", function () {
    displayValue.textContent = this.value;
    sizeObb = this.value;
});

rangeSeconds.addEventListener("input", function () {
    displayValueSeconds.textContent = this.value;
    seconds = this.value;
});

function createMenuObb () {
    if (showObb.style.display == "block")
        showObb.style.display = "none";
    else if (showPhoto.style.display == "block") {
        showPhoto.style.display = "none";
        showObb.style.display = "block";
    }
    else 
        showObb.style.display = "block";
}

function createMenuPhoto () {
    if (showPhoto.style.display == "block") {
        showPhoto.style.display = "none";
    }
    else if (showObb.style.display == "block"){
        showObb.style.display = "none";
        showPhoto.style.display = "block";
    }
    else 
        showPhoto.style.display = "block";
}